package com.varxyz.fStation.domain;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Text {
	private long tId;
	private String passwd;
	private String content;
	private Date regDate;
	private Date deleteDate;
}
