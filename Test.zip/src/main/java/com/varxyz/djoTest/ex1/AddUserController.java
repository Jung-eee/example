package com.varxyz.djoTest.ex1;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mysql.cj.Session;

@Controller
public class AddUserController {
	@Autowired
	UserImp userService;
	
	@GetMapping("/user/add_user")
	public String addUserForm() {
		return "user/add_user";
	}
	
	@PostMapping("/user/add_user")
	public String addUser(UserCommand userCommand, HttpServletRequest request, Model model) {
		model.addAttribute("userCommand",userCommand);
		User user = new User();
		user.setUserId(userCommand.getUserId());
		user.setPasswd(userCommand.getPasswd());
		user.setUserName(userCommand.getUserName());
		userService.addUser(user);
		
		
		user = userService.idCh(user);
		if (user != null) {
			request.setAttribute("msg", "중복 된 아이디 입니다.");
			request.setAttribute("url", "add_user");
			return "alert";
		}
		model.addAttribute("userName", userCommand.getUserName());
		return "user/add_user_sus";
		
		
	}
}
