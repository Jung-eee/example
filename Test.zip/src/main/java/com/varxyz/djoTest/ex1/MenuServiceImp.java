package com.varxyz.djoTest.ex1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class MenuServiceImp implements AddMenuService {
	@Autowired
	MenuDao menuDao;

	@Override
	public void addMenu(Menu menu) {
		menuDao.addMenu(menu);
	}

	@Override
	public List<Menu> viewAllMenu() {
		return menuDao.viewAllMenu();
	}

}
