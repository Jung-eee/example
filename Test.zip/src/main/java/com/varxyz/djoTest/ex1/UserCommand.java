package com.varxyz.djoTest.ex1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserCommand {
	private String userId;
	private String passwd;
	private String userName;
}
