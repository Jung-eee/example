package com.varxyz.djoTest.ex1;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;



@Controller
public class AddMenuController {
	@Autowired
	MenuServiceImp menuService;
	
	@GetMapping("/menu/add_menu")
	public String addmenuFrom(MenuCommand menuCommand) {
		return "menu/add_menu";
	}
	@GetMapping("/menu/view_menu")
	public String toMain() {
		return "menu/view_menu";
	}
	
	@PostMapping("/menu/add_menu")
	public String addMenuItem(MenuCommand menuCommand, Model model, HttpServletRequest request) throws IOException {
		model.addAttribute("menuItemCommand", menuCommand);
		Menu menu = new Menu();		
		menu.setMenuName(menuCommand.getMenuName());
		menu.setMenuPrice(menuCommand.getMenuPrice());
		menu.setMenuType(menuCommand.getMenuType());
		
		return "menu/add_success_menu";
	}
	
}
