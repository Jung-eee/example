package com.varxyz.djoTest.ex1;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;


public class UserDao {
private JdbcTemplate jdbcTemplate;
	
	public UserDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void addUser(User user) {
		String sql = "INSERT INTO User (userId, passwd, userName)"
				+ " VALUES(?, ?, ?)";
		jdbcTemplate.update(sql, user.getUserId(), user.getPasswd(), user.getUserName());
		System.out.println("회원가입 성공");
		
		
		
	}
	//회원가입 유효성 체크
	public User idCh(User user) {
		String sql = "	SELECT * FROM User"
				+ "	WHERE userId = ?";
		try {
			return jdbcTemplate.queryForObject(sql,new RowMapper<User>() {

				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
					user.setUserId(rs.getString("userId"));
					user.setPasswd(rs.getString("passwd"));
					user.setUserName(rs.getString("userName"));
					return user;
				}
				
			}, user.getUserId());
			
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	//로그인 유효성 체크
	public User loginCh(User user) {
		String sql = "SELECT * FROM USER "
				+ "WHERE userId = ? AND passwd = ?";
		try {
			return jdbcTemplate.queryForObject(sql,new RowMapper<User>() {

				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
					user.setUserId(rs.getString("userId"));
					user.setPasswd(rs.getString("passwd"));
					user.setUserName(rs.getString("userName"));
					return user;
				}
				
			}, user.getUserId(), user.getPasswd());
			
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
				
	}

}
