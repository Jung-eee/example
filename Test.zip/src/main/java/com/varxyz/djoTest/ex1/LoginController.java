package com.varxyz.djoTest.ex1;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@Autowired
	UserImp userService;
	
	@GetMapping("/login/login")
	public String loginForm() {
		 return "login/login";
	}
	@PostMapping("/login/login")
	public String login(HttpServletRequest request, HttpSession session, @RequestParam("userId") String userId, @RequestParam("passwd") String passwd ) {
		User user = new User();
		user.setUserId(userId);
		user.setPasswd(passwd);
		
		user = userService.loginCh(user);
		if (user == null) {
			request.setAttribute("msg", "아이디 혹은 비밀번호가 틀렸습니다.");
			request.setAttribute("url", "login");
			return "alert";
		}
		session.setAttribute("user", user);
		return "login/su_login";
	}
	
	@PostMapping("/login/su_login")
	public String logout(HttpSession session){
		userService.logout(session);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login/login");
		mav.addObject("msg", "로그아웃");
		return "login/login";
	}
}
