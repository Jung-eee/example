package com.varxyz.djoTest.ex1;

import java.util.List;

public interface AddMenuService {
	
	void addMenu(Menu menu);
	List<Menu> viewAllMenu();
}
