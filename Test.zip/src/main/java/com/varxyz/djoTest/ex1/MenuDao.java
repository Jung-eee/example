package com.varxyz.djoTest.ex1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;



public class MenuDao {
private JdbcTemplate jdbcTemplate;

	public MenuDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	//메뉴 등록
	public void addMenu(Menu menu) {
		String sql = "INSERT INTO MenuItem (menuName, menuPrice, menuType)"
				+ " VALUES(?, ?, ?)";
		jdbcTemplate.update(sql, menu.getMenuName(), menu.getMenuPrice(), menu.getMenuType());
		System.out.println("메뉴 등록 완료");
	}
	
	//전체메뉴 보기
	public List<Menu> viewAllMenu() {
		String sql = "SELECT m.menuName, m.menuPrice, m.menuType";
		
		return jdbcTemplate.query(sql, new RowMapper<Menu>() {

			@Override
			public Menu mapRow(ResultSet rs, int rowNum) throws SQLException {
				Menu menu = new Menu(rs.getString("menuName"), rs.getInt("menuPrice"), rs.getString("menuType"));
				return menu;
			}
			
		});
	}
}
