package com.varxyz.djoTest.ex1;

import javax.servlet.http.HttpSession;

public interface UserService {
	
	void addUser(User user);
	void logout(HttpSession session);
	User idCh(User user);
	User loginCh(User user);
}
