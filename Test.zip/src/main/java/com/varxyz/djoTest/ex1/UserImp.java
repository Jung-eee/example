package com.varxyz.djoTest.ex1;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

public class UserImp implements UserService{
	@Autowired
	UserDao userDao;

	@Override
	public void logout(HttpSession session) {
		 session.invalidate();
	}

	@Override
	public User idCh(User user) {
		return userDao.idCh(user);
	}

	@Override
	public void addUser(User user) {
		userDao.addUser(user);
		
	}

	@Override
	public User loginCh(User user) {
		return userDao.loginCh(user);
	}

	

	

}
