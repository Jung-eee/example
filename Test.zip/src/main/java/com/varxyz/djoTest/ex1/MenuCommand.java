package com.varxyz.djoTest.ex1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuCommand {
	private String menuName;
	private int MenuPrice;
	private String MenuType;
}
