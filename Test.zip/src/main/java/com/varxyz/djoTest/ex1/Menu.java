package com.varxyz.djoTest.ex1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Menu {
	private long mid;
	private int menuPrice;
	private String menuName;
	private String menuType;
	
	public Menu() {
		
	}

	public Menu(String menuName, int menuPrice,  String menuType) {
		this.menuName = menuName;
		this.menuPrice = menuPrice;
		this.menuType = menuType;
	}
	
	
	
	
}
