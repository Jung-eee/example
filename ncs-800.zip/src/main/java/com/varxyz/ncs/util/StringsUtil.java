package com.varxyz.ncs.util;

public class StringsUtil {
	
	/**
	 * 주어진 문자열에 숫자(양수에 한함)와 관련된 문자열을 추출하여 리턴한다.
	 * 숫자가 없을때 빈문자열을 리턶나다.
	 * 
	 * ex) "abc432def" 입력시 "432" 출력
	 * 
	 * @param target
	 * @return
	 */
	public String extractIntCharacters(String str) {
		char[] ch = str.toCharArray();
		String re = "";
		for (int i = 0; i < ch.length; i++) {
			if ((int)ch[i] >= 48 && (int)ch[i] <= 57) {
				re += ch[i];
			}
		}
		return re;
	}
	
	
	/**
	 * 주어진 문자열에 포함된 숫자(양수에 한함)문자열을 정수로 리턴한다.
	 * 숫자가 없을때 IllegalArguemntException 예외를 던진다.
	 * 
	 * ex) "abc432def" 입력시 432 출력
	 * @param target
	 * @return
	 */
	public int extractNum(String target) {
		char[] ch = target.toCharArray();
		String re = "";
		for (int i = 0; i < ch.length; i++) {
			if ((int)ch[i] >= 48 && (int)ch[i] <= 57) {
				re += ch[i];
			}
		}
		if (re.equals("")) {
			throw new IllegalArgumentException("예외");
		}
		return Integer.parseInt(re);
	}
	
}
