package jv251.varxyz.jv251.exception;

public class EntityNotFoundException extends Exception {
	public EntityNotFoundException (String msg) {
		super(msg);
	}
}
