package jv251.varxyz.jv251.exception;

public class CustomerNotFoundException extends EntityNotFoundException{
	public CustomerNotFoundException(String msg) {
		super(msg);
	}
}
