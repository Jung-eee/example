package jv251.varxyz.jv251.exception;

public class DuplicatedEntityException extends RuntimeException {
	public DuplicatedEntityException(String msg) {
		super(msg);
	}
}
