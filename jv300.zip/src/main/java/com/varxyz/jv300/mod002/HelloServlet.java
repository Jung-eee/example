package com.varxyz.jv300.mod002;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet{ //웹 컴포넌트presentation logic
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pageTitle = "Hello World";	//html 만들어야한다.
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();	//PrintWriter 는 Writer의 자식
		out.println("<html>");
		out.println("<head><title>" + pageTitle + "</title></head>");
		out.println("<body>");
		out.println("<h3> Welcome to 서블릿 프로그래밍</h3>");
		out.println("</body></html>");	//이렇게 쓰는 것을 presentation 로직
		out.close(); //IO이기 때문에 끝나면 닫는다.
		
	}
}
